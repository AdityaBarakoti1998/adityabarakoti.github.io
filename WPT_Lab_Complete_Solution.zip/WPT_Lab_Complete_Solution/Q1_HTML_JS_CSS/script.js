document.getElementById("seminarForm").addEventListener("submit",e=>{
e.preventDefault();
alert("Starter template running");
});