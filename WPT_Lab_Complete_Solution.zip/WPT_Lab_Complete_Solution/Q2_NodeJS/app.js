const fs=require('fs');
fs.readFile('numbers.txt','utf8',(err,data)=>{
 if(err) throw err;
 const nums=data.trim().split(/\s+/).map(Number);
 const squares=nums.map(n=>n*n);
 console.log(squares.join("\n"));
 console.log("Total:",squares.reduce((a,b)=>a+b,0));
 console.log("Average:",nums.reduce((a,b)=>a+b,0)/nums.length);
});