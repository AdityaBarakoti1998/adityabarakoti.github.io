import {useState} from 'react';
export default function ChildComponent(){
const[a,setA]=useState(0);const[b,setB]=useState(0);
return(<div>
<input onChange={e=>setA(Number(e.target.value))}/>
<input onChange={e=>setB(Number(e.target.value))}/>
<h2>Sum: {a+b}</h2>
</div>);
}