import ChildComponent from './ChildComponent';
export default function App(){return <ChildComponent/>;}