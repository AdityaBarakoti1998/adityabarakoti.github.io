Web Programming Technologies - Lab Exam Solution
===================================================

Q1 (Seminar_Registration_Form) - folder Q1
--------------------------------------------
File: seminar_registration.html
- Open directly in any browser (Chrome/Firefox).
- Fill in the form, click "Calculate Training Cost" to see the read-only
  cost field populate based on Seminar + Level.
- Click "Submit" -> validates all fields (mandatory checks, email format,
  email match) and shows the alert "All data entered correctly" only
  when everything is valid.
- Click "Display Details" -> opens a new window listing all
  participants submitted so far, with name shown as a single
  concatenated string (Title + First + Last).

Q2 (NodeJS) - folder Q2
-------------------------
Files: numbers.txt, squareCalc.js
- numbers.txt contains the sample numbers (1 to 5) from the question.
- Run with: node squareCalc.js
- Output prints the square of each number, then "Total :" (sum of
  squares) and "Average:" (average of the original numbers) - matches
  the sample output given in the paper exactly.

Q3 (React) - folder Q3
-------------------------
Files: App.js, ChildComponent.js
- ChildComponent.js: a form with Number1, Number2 inputs and an Add
  button. Values are held in component state; clicking Add computes
  and displays the sum inside the same component.
- App.js: imports and renders ChildComponent.
- To run: drop both files into the src/ folder of any Create React App
  project (npx create-react-app my-app), replacing the default App.js,
  then `npm start`.
