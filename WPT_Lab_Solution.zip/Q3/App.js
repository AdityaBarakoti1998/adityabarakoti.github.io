import React from "react";
import ChildComponent from "./ChildComponent";

function App() {
    return (
        <div style={{
            display: "flex",
            justifyContent: "center",
            marginTop: "60px"
        }}>
            <ChildComponent />
        </div>
    );
}

export default App;
