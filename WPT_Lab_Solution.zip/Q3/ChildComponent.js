import React, { useState } from "react";

// ChildComponent: takes two numbers from the user via a small form,
// keeps them in state, and shows their sum in the same component.
function ChildComponent() {
    const [num1, setNum1] = useState("");
    const [num2, setNum2] = useState("");
    const [sum, setSum] = useState(null);

    const handleAdd = () => {
        const n1 = parseFloat(num1) || 0;
        const n2 = parseFloat(num2) || 0;
        setSum(n1 + n2);
    };

    return (
        <div style={{
            border: "1px solid #4a76a8",
            borderRadius: "6px",
            padding: "18px 22px",
            maxWidth: "280px",
            fontFamily: "Arial, sans-serif"
        }}>
            <div style={{ marginBottom: "10px" }}>
                <label style={{ marginRight: "8px" }}>Number1 :</label>
                <input
                    type="number"
                    value={num1}
                    onChange={(e) => setNum1(e.target.value)}
                />
            </div>

            <div style={{ marginBottom: "10px" }}>
                <label style={{ marginRight: "8px" }}>Number2 :</label>
                <input
                    type="number"
                    value={num2}
                    onChange={(e) => setNum2(e.target.value)}
                />
            </div>

            <button onClick={handleAdd} style={{ marginBottom: "14px" }}>
                Add
            </button>

            {sum !== null && (
                <h3 style={{ textAlign: "center", margin: 0 }}>
                    Sum is : {sum}
                </h3>
            )}
        </div>
    );
}

export default ChildComponent;
