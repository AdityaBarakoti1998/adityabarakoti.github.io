// squareCalc.js
// Reads a file of numbers (one per line), prints the square of each,
// then the total of the squares and the average of the ORIGINAL numbers.

const fs = require("fs");
const path = require("path");

const inputFile = path.join(__dirname, "numbers.txt");

fs.readFile(inputFile, "utf8", function (err, data) {
    if (err) {
        console.error("Could not read file:", err.message);
        return;
    }

    // Split on any newline, drop empty lines, convert to numbers
    const numbers = data
        .split(/\r?\n/)
        .filter(function (line) { return line.trim() !== ""; })
        .map(Number);

    let sumOfSquares = 0;
    let sumOfOriginal = 0;

    numbers.forEach(function (num) {
        const square = num * num;
        console.log(square);
        sumOfSquares += square;
        sumOfOriginal += num;
    });

    const average = sumOfOriginal / numbers.length;

    console.log("Total :", sumOfSquares);
    console.log("Average:", average);
});
