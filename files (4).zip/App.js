/* ==========================================================
   GENERIC REACT TEMPLATE
   Parent component just imports and renders the child.
   All the actual logic (state, form, sum) lives in the child
   — that's what most CDAC React questions ask for.
   ========================================================== */

import React from 'react';
import ChildComponent from './ChildComponent';

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '40px' }}>
      <ChildComponent />
    </div>
  );
}

export default App;
