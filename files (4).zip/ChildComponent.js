/* ==========================================================
   GENERIC REACT CHILD COMPONENT TEMPLATE
   Pattern: take input(s) in a form, save in state, do a
   calculation (sum here), display result in same component.

   To reuse for a DIFFERENT question (e.g. average, product,
   concatenation): only change the calculate() function below.
   ========================================================== */

import React, { useState } from 'react';

function ChildComponent() {
  // one state variable per input field
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState(null);

  function calculate() {
    const n1 = Number(num1);
    const n2 = Number(num2);
    setResult(n1 + n2); // change this line for other operations
  }

  return (
    <div style={{
      border: '2px solid darkblue',
      borderRadius: '10px',
      padding: '20px',
      width: '280px',
      margin: 'auto'
    }}>
      <div style={{ marginBottom: '10px' }}>
        <label>Number1 : </label>
        <input
          type="number"
          value={num1}
          onChange={(e) => setNum1(e.target.value)}
        />
      </div>

      <div style={{ marginBottom: '10px' }}>
        <label>Number2 : </label>
        <input
          type="number"
          value={num2}
          onChange={(e) => setNum2(e.target.value)}
        />
      </div>

      <button onClick={calculate}>Add</button>

      {result !== null && (
        <h3>Sum is : {result}</h3>
      )}
    </div>
  );
}

export default ChildComponent;
