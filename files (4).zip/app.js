/* ==========================================================
   GENERIC NODE.JS TEMPLATE
   Question pattern: read numbers from a file, do some
   calculation on each, then show a total/average/etc.

   Run with:  node app.js
   ========================================================== */

const fs = require('fs');

fs.readFile('numbers.txt', 'utf8', (err, data) => {
  if (err) {
    console.log("Error reading file:", err);
    return;
  }

  // split file into lines, remove empty lines, convert to numbers
  const numbers = data
    .split('\n')
    .map(line => line.trim())
    .filter(line => line !== '')
    .map(Number);

  // calculate square of each number
  const squares = numbers.map(n => n * n);

  // sum of squares
  const totalOfSquares = squares.reduce((sum, sq) => sum + sq, 0);

  // average of ORIGINAL numbers (not squares) — read the question carefully,
  // sometimes they ask average of squares instead
  const average = numbers.reduce((sum, n) => sum + n, 0) / numbers.length;

  console.log("Original numbers:", numbers);
  console.log("Squares:");
  squares.forEach(sq => console.log(sq));
  console.log("Total :", totalOfSquares);
  console.log("Average:", average);
});
