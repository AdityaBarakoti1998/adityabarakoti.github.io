/* ==========================================================
   GENERIC FORM TEMPLATE — reusable for Seminar / Student /
   Employee / Course registration type questions.

   Change ONLY the CHARGES object below to match whatever
   pricing/marks table the actual question paper gives you.
   Everything else (validation, display logic) stays same.
   ========================================================== */

// 1. COST TABLE — edit this per the question's table
const CHARGES = {
  "SOA": { "Introductory": 2500, "Intermediate": 3500, "Advanced": 6000 },
  "Design Patterns": { "Introductory": 4000, "Intermediate": 5500, "Advanced": 8000 },
  "Business Intelligence": { "Introductory": 5000, "Intermediate": 7000, "Advanced": 10000 }
};

// Keeps track of everyone who has submitted successfully.
// This is what lets "Display All Details" show ALL participants,
// not just the last one (the paper explicitly asks for "all").
let participants = [];
let isFormValid = false;

// 2. COST CALCULATION
function calculateCost() {
  const category = document.getElementById("category").value;
  const level = document.getElementById("level").value;

  const cost = (CHARGES[category] && CHARGES[category][level]) || 0;
  document.getElementById("cost").value = cost;
}

// 3. EMAIL FORMAT CHECK (simple, exam-safe regex)
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// 4. FORM SUBMIT VALIDATION
document.getElementById("regForm").addEventListener("submit", function (event) {
  event.preventDefault(); // stop page refresh so validation can run

  const title = document.getElementById("title").value;
  const fname = document.getElementById("fname").value.trim();
  const lname = document.getElementById("lname").value.trim();
  const email = document.getElementById("email").value.trim();
  const confirmEmail = document.getElementById("confirmEmail").value.trim();
  const category = document.getElementById("category").value;
  const level = document.getElementById("level").value;
  const cost = document.getElementById("cost").value;

  // all text fields mandatory
  if (fname === "" || lname === "" || email === "" || confirmEmail === "") {
    alert("All fields are mandatory");
    isFormValid = false;
    return;
  }

  // emails must match
  if (email !== confirmEmail) {
    alert("Emails do not match");
    isFormValid = false;
    return;
  }

  // emails must be valid format
  if (!isValidEmail(email) || !isValidEmail(confirmEmail)) {
    alert("Please enter a valid email address");
    isFormValid = false;
    return;
  }

  // cost must have been calculated
  if (category === "" || level === "" || cost === "" || cost === "0") {
    alert("Please select category and level, then click Calculate Cost");
    isFormValid = false;
    return;
  }

  // all good — save this participant
  isFormValid = true;
  participants.push({
    fullName: title + " " + fname + " " + lname, // concatenated as one string, e.g. "Dr Manoj Singh"
    email: email,
    category: category,
    level: level,
    cost: cost
  });

  alert("All data entered correctly");
});

// 5. DISPLAY ALL DETAILS — only works after a valid submit,
//    and shows EVERY participant submitted so far.
function displayDetails() {
  if (!isFormValid || participants.length === 0) {
    alert("Please submit valid data first.");
    return;
  }

  const win = window.open("", "_blank");
  win.document.write("<h2>Participant Details</h2>");

  participants.forEach((p, i) => {
    win.document.write("<p><b>Participant " + (i + 1) + "</b><br>");
    win.document.write("Name : " + p.fullName + "<br>");
    win.document.write("Email : " + p.email + "<br>");
    win.document.write("Category : " + p.category + "<br>");
    win.document.write("Level : " + p.level + "<br>");
    win.document.write("Cost : " + p.cost + "</p><hr>");
  });
}
